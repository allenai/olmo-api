import unittest
from asyncio import Event, Future
from typing import Generator, Optional
from unittest.mock import MagicMock

import grpc
from google.protobuf.duration_pb2 import Duration
from google.protobuf.struct_pb2 import Struct, Value

from .model import Config, Model, _run
from .msg.inferd_pb2 import (
    ClaimWorkRequest,
    ClaimWorkResponse,
    ComputeWorker,
    InferenceMetadata,
    PublishResultRequest,
    RegisterComputeWorkerRequest,
    RegisterComputeWorkerResponse,
    WorkerInput,
)


class TestRun(unittest.IsolatedAsyncioTestCase):
    async def test_run(self):
        test_channel = MagicMock(name="channel")

        test = self
        load_called = False

        class _TestModel(Model):
            def load(self):
                nonlocal load_called
                load_called = True

            def generate(self, inp: dict) -> Generator[dict, None, None]:
                test.assertEqual(inp, {"input": "test-in"})
                yield {"output": "test-out"}

        class _TestConfig(Config):
            def __init__(self):
                super().__init__(host="test-host", compute_source_id="test-cs-id", token="test-token")

            def channel(self) -> grpc.aio.Channel:
                return test_channel

        mock_claim_work_stream = MagicMock(name="mock_claim_work_stream")
        mock_claim_work_stream.__aiter__.return_value = iter(
            [
                ClaimWorkResponse(
                    batch=[
                        WorkerInput(
                            metadata=InferenceMetadata(
                                inference_id="test-inference-id",
                                queue_id="test-queue-id",
                                compute_source_id="test-cs-id",
                                compute_worker_id="test-worker-id",
                            ),
                            input=Struct(fields={"input": Value(string_value="test-in")}),
                        )
                    ]
                ),
            ]
        )
        mock_claim_work_stream.__anext__.side_effect = mock_claim_work_stream.__aiter__.return_value.__next__

        mock_publish_results_stream = MagicMock(name="mock_publish_results_stream")

        event = Event()

        def register_compute_worker_handler(register_compute_worker_request, wait_for_ready, metadata):
            details = Struct(
                fields={
                    "host": Value(string_value="test-host"),
                    "compute_source_id": Value(string_value="test-cs-id"),
                    "batch_size": Value(number_value=1),
                    "block_timeout_ms": Value(number_value=100),
                    "max_claimed_batches": Value(number_value=1),
                    "use_insecure_channel": Value(bool_value=False),
                }
            )
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))
            self.assertEqual(
                register_compute_worker_request,
                RegisterComputeWorkerRequest(
                    compute_source_id="test-cs-id",
                    worker_details=details,
                ),
            )
            f: Future = Future()
            f.set_result(
                RegisterComputeWorkerResponse(
                    compute_worker=ComputeWorker(
                        id="test-worker-id",
                        compute_source_id="test-cs-id",
                        worker_details=details,
                    )
                )
            )
            return f

        def claim_work_handler(claim_work_request, wait_for_ready, metadata):
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))
            self.assertEqual(
                claim_work_request,
                ClaimWorkRequest(
                    compute_source_id="test-cs-id",
                    compute_worker_id="test-worker-id",
                    batch_size=1,
                    block_timeout=Duration(nanos=100000000),
                    max_claimed_batches=1,
                ),
            )
            return mock_claim_work_stream

        async def publish_result_handler(publish_result_request_stream, wait_for_ready, metadata):
            publish_result_request: PublishResultRequest = await anext(publish_result_request_stream)
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))
            self.assertEqual(
                publish_result_request.output.metadata,
                InferenceMetadata(
                    inference_id="test-inference-id",
                    queue_id="test-queue-id",
                    compute_source_id="test-cs-id",
                    compute_worker_id="test-worker-id",
                ),
            )
            self.assertEqual(
                publish_result_request.output.output, Struct(fields={"output": Value(string_value="test-out")})
            )
            self.assertGreater(publish_result_request.output.started_inference_at.ToNanoseconds(), 0)
            self.assertGreater(publish_result_request.output.completed_inference_at.ToNanoseconds(), 0)
            event.set()
            return mock_publish_results_stream

        # RegisterComputeWorker is currently the only unary_unary method, ClaimWork is currently the only unary_stream,
        # and PublishResult is the only stream_unary method, so we can mock them directly here.
        test_channel.unary_unary.return_value = MagicMock(
            name="register_compute_worker_handler", side_effect=register_compute_worker_handler
        )
        test_channel.unary_stream.return_value = MagicMock(name="claim_work_handler", side_effect=claim_work_handler)
        test_channel.stream_unary.return_value = MagicMock(
            name="publish_result_handler", side_effect=publish_result_handler
        )
        test_channel.wait_for_state_change.return_value = Future()

        await _run(event, _TestModel(), _TestConfig())
        self.assertTrue(load_called)

    async def test_run_batch(self):
        test_channel = MagicMock(name="channel")

        test = self
        load_called = False

        class _TestBatchModel(Model):
            def load(self):
                nonlocal load_called
                load_called = True

            def batch_generate(self, inp: list[dict]) -> Generator[list[Optional[dict]], None, None]:
                test.assertEqual(inp, [{"input": "test-in-1"}, {"input": "test-in-2"}])
                yield [{"output": "test-out-1"}, {"output": "test-out-2"}]

        class _TestBatchConfig(Config):
            def __init__(self):
                super().__init__(host="test-host", compute_source_id="test-cs-id", batch_size=2, token="test-token")

            def channel(self) -> grpc.aio.Channel:
                return test_channel

        mock_claim_work_stream = MagicMock(name="mock_claim_work_stream")
        mock_claim_work_stream.__aiter__.return_value = iter(
            [
                ClaimWorkResponse(
                    batch=[
                        WorkerInput(
                            metadata=InferenceMetadata(
                                inference_id="test-inference-id-1",
                                queue_id="test-queue-id",
                                compute_source_id="test-cs-id",
                                compute_worker_id="test-worker-id",
                            ),
                            input=Struct(fields={"input": Value(string_value="test-in-1")}),
                        ),
                        WorkerInput(
                            metadata=InferenceMetadata(
                                inference_id="test-inference-id-2",
                                queue_id="test-queue-id",
                                compute_source_id="test-cs-id",
                                compute_worker_id="test-worker-id",
                            ),
                            input=Struct(fields={"input": Value(string_value="test-in-2")}),
                        ),
                    ]
                ),
            ]
        )
        mock_claim_work_stream.__anext__.side_effect = mock_claim_work_stream.__aiter__.return_value.__next__

        mock_publish_results_stream = MagicMock(name="mock_publish_results_stream")

        event = Event()

        def register_compute_worker_handler(register_compute_worker_request, wait_for_ready, metadata):
            details = Struct(
                fields={
                    "host": Value(string_value="test-host"),
                    "compute_source_id": Value(string_value="test-cs-id"),
                    "batch_size": Value(number_value=2),
                    "block_timeout_ms": Value(number_value=100),
                    "max_claimed_batches": Value(number_value=1),
                    "use_insecure_channel": Value(bool_value=False),
                }
            )
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))
            self.assertEqual(
                register_compute_worker_request,
                RegisterComputeWorkerRequest(
                    compute_source_id="test-cs-id",
                    worker_details=details,
                ),
            )
            f: Future = Future()
            f.set_result(
                RegisterComputeWorkerResponse(
                    compute_worker=ComputeWorker(
                        id="test-worker-id",
                        compute_source_id="test-cs-id",
                        worker_details=details,
                    )
                )
            )
            return f

        def claim_work_handler(claim_work_request, wait_for_ready, metadata):
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))
            self.assertEqual(
                claim_work_request,
                ClaimWorkRequest(
                    compute_source_id="test-cs-id",
                    compute_worker_id="test-worker-id",
                    batch_size=2,
                    block_timeout=Duration(nanos=100000000),
                    max_claimed_batches=1,
                ),
            )
            return mock_claim_work_stream

        published = 0

        async def publish_result_handler(publish_result_request_stream, wait_for_ready, metadata):
            nonlocal published
            publish_result_request: PublishResultRequest = await anext(publish_result_request_stream)
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(metadata, (("x-inferd-token", "test-token"),))

            # The order of the results is not guaranteed, so we need to check both possibilities.
            is_request_1 = publish_result_request.output.metadata.inference_id == "test-inference-id-1"

            self.assertEqual(
                publish_result_request.output.metadata,
                InferenceMetadata(
                    inference_id="test-inference-id-1" if is_request_1 else "test-inference-id-2",
                    queue_id="test-queue-id",
                    compute_source_id="test-cs-id",
                    compute_worker_id="test-worker-id",
                ),
            )
            self.assertEqual(
                publish_result_request.output.output,
                Struct(fields={"output": Value(string_value="test-out-1" if is_request_1 else "test-out-2")}),
            )
            self.assertGreater(publish_result_request.output.started_inference_at.ToNanoseconds(), 0)
            self.assertGreater(publish_result_request.output.completed_inference_at.ToNanoseconds(), 0)
            published += 1
            if published == 2:
                event.set()
            return mock_publish_results_stream

        # RegisterComputeWorker is currently the only unary_unary method, ClaimWork is currently the only unary_stream,
        # and PublishResult is the only stream_unary method, so we can mock them directly here.
        test_channel.unary_unary.return_value = MagicMock(
            name="register_compute_worker_handler", side_effect=register_compute_worker_handler
        )
        test_channel.unary_stream.return_value = MagicMock(name="claim_work_handler", side_effect=claim_work_handler)
        test_channel.stream_unary.return_value = MagicMock(
            name="publish_result_handler", side_effect=publish_result_handler
        )
        test_channel.wait_for_state_change.return_value = Future()

        await _run(event, _TestBatchModel(), _TestBatchConfig())
        self.assertTrue(load_called)
