import logging
import os
from abc import ABC, abstractmethod
from asyncio import Event, TaskGroup
from dataclasses import dataclass
from signal import SIGINT, signal
from time import time_ns
from typing import Generator, Optional, TypeVar
from uuid import uuid4

import grpc
from google.protobuf import json_format
from google.protobuf.duration_pb2 import Duration
from google.protobuf.struct_pb2 import Struct

from .msg.inferd_pb2 import ClaimWorkRequest, PublishResultRequest, WorkerOutput
from .msg.inferd_pb2_grpc import InferDStub


class Model(ABC):
    def __init__(self):
        ...

    @abstractmethod
    def load(self):
        ...

    @abstractmethod
    def generate(self, inp: dict) -> Generator[dict, None, None]:
        ...


@dataclass
class Config:
    host: str
    compute_source_id: str
    compute_node_id: str

    @classmethod
    def from_env(cls) -> "Config":
        return Config(
            host=os.environ["INFERD_HOST"],
            compute_source_id=os.environ["INFERD_COMPUTE_SOURCE_ID"],
            compute_node_id=str(uuid4()),
        )

    def channel(self) -> grpc.aio.Channel:
        return grpc.aio.insecure_channel(self.host)


M = TypeVar("M", bound=Model)
C = TypeVar("C", bound=Config)


async def run(model: Model, config: Optional[Config] = None):
    # Initialize the config from the environment if it is not provided.
    if config is None:
        config = Config.from_env()

    event = Event()
    signal(SIGINT, lambda signum, frame: event.set())  # pyright: ignore unusedVariable
    await _run(event, model, config)
    logging.info("exiting...")


async def _generate(stream: grpc.aio.UnaryStreamCall, stub: InferDStub, config: Config, model: Model):
    async for response in stream:
        if response == grpc.aio.EOF:
            break
        rids = [b.request_id for b in response.batch]
        logging.info(f"received batch size {len(response.batch)} with requests {', '.join(rids)}")

        try:
            batch_input = []
            for worker_input in response.batch:
                assert (
                    worker_input.compute_source_id == config.compute_source_id
                ), f"request compute source id does not match config compute source id: {config.compute_source_id}"
                logging.debug(f"enqueuing request {worker_input.request_id}")
                batch_input.append(json_format.MessageToDict(worker_input.input))

            async def generate_and_publish(inp: dict):
                def iterator():
                    try:
                        output_generator = model.generate(inp)
                        while True:
                            output = Struct()
                            start, duration = time_ns(), Duration()
                            out = next(output_generator, None)
                            if out is None:
                                break
                            output.update(out)
                            duration.FromNanoseconds(time_ns() - start)

                            worker_output = WorkerOutput(
                                output=output, inference_time=duration, queue_time=worker_input.queue_time
                            )
                            logging.debug("publishing output for request %s", worker_input.request_id)
                            yield PublishResultRequest(
                                compute_node_id=config.compute_node_id, input=worker_input, output=worker_output
                            )
                    except Exception as e:
                        # TODO: dispatch error to stream
                        logging.error(e)
                        return

                await stub.PublishResult(iterator(), wait_for_ready=True)

            # TODO: implement dynamic batching instead of sequential processing
            for i in batch_input:
                await generate_and_publish(i)

        except Exception as e:
            # TODO: dispatch error to stream
            logging.error(e)
            continue


async def _run(event: Event, model: Model, config: Config):
    logging.info("loading model...")
    model.load()

    channel = config.channel()
    stub = InferDStub(channel)

    # Wrap the ClaimWork stream connection in a retry loop, since this is a long-running connection. If the
    # connection is lost, we want to retry, which will block until the server becomes available again. Therefore,
    # we don't need to use an exponential backoff strategy here.
    while True:
        try:
            logging.info("claiming work for model...")
            claim_work_request = ClaimWorkRequest(
                compute_source_id=config.compute_source_id, compute_node_id=config.compute_node_id
            )
            claim_work_stream = stub.ClaimWork(claim_work_request, wait_for_ready=True)

            async with TaskGroup() as tg:
                generate_task = tg.create_task(_generate(claim_work_stream, stub, config, model))
                await event.wait()
                generate_task.cancel()

            break

        # If the exception group contains one grpc.aio.AioRpcError error, trigger this block.
        except* grpc.aio.AioRpcError as e:
            # Find the grpc.aio.AioRpcError error.
            for err in e.exceptions:
                # If the error is retryable (probably b/c the socket got lost) continue, otherwise re-raise.
                if isinstance(err, grpc.aio.AioRpcError) and err.code() == grpc.StatusCode.UNAVAILABLE:
                    logging.info("caught grpc.aio.AioRpcError exception with status=UNAVAILABLE; retrying...")
                    break
            else:
                raise e

    logging.info("Exiting worker...")
