import atexit
import os
from typing import Generator, Optional

import grpc
from google.protobuf import json_format
from google.protobuf.struct_pb2 import Struct

from .errors import ConfigError, InvalidReferenceError
from .msg.inferd_pb2 import (
    InferRequest,
    InferResponse,
    ListModelsRequest,
    ListModelsResponse,
)
from .msg.inferd_pb2_grpc import InferDStub


class Client:
    addr: str
    client: InferDStub
    token: Optional[str]

    def __init__(self, addr: str, token: str):
        channel: grpc.Channel
        if (
            addr.startswith("localhost") or addr.startswith("0.0.0.0") or addr.startswith("system")
        ) and not addr.endswith(":443"):
            channel = grpc.insecure_channel(addr)
        else:
            if not token:
                raise ConfigError("INFERD_TOKEN must be set")
            channel = grpc.secure_channel(addr, grpc.ssl_channel_credentials())

        atexit.register(channel.close)

        self.client = InferDStub(channel)
        self.token = token

    @classmethod
    def from_env(cls) -> "Client":
        addr = os.getenv("INFERD_ADDR", "grpc-inferd.allen.ai:443")
        token = os.getenv("INFERD_TOKEN", "")
        return cls(addr, token)

    def _build_request_metadata(self) -> tuple[tuple[str, Optional[str]]]:
        return (("x-inferd-token", self.token),)

    def _build_infer_request(self, ref: str, payload: dict) -> InferRequest:
        inp = Struct()
        inp.update(payload)

        if ref.startswith("csc"):
            return InferRequest(compute_source_id=ref, input=inp)
        elif ref.startswith("mov"):
            return InferRequest(model_version_id=ref, input=inp)
        elif ref.startswith("mod"):
            return InferRequest(model_id=ref, input=inp)
        elif "/" not in ref:
            raise InvalidReferenceError(f"invalid model reference: {ref}")

        parts = ref.split("/")
        if len(parts) != 2:
            raise InvalidReferenceError(f"invalid model reference: {ref}")

        req = ListModelsRequest(organization_id=parts[0], name=parts[1], page_size=1)
        res: ListModelsResponse = self.client.ListModels(req, metadata=self._build_request_metadata())
        if not res.models or len(res.models) != 1:
            raise InvalidReferenceError(f"model with organization_id '{parts[0]}' and name '{parts[1]}' not found")
        return InferRequest(model_id=res.models[0].id, input=inp)

    def infer(self, ref: str, payload: dict) -> Generator[dict, None, None]:
        req = self._build_infer_request(ref, payload)
        res: InferResponse
        for res in self.client.Infer(req, metadata=self._build_request_metadata()):
            output = res.result.output
            yield json_format.MessageToDict(output)
