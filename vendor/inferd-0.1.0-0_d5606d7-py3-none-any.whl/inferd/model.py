import logging
import os
from abc import ABC, abstractmethod
from asyncio import Event, TaskGroup
from signal import SIGINT, signal
from time import time_ns
from typing import Generator, Type, TypeVar
from uuid import uuid4

import grpc
from google.protobuf import json_format
from google.protobuf.duration_pb2 import Duration
from google.protobuf.struct_pb2 import Struct

from .msg.inferd_pb2 import ClaimWorkRequest, PublishResultRequest, WorkerOutput
from .msg.inferd_pb2_grpc import InferDStub


class Model(ABC):
    def __init__(self):
        ...

    @abstractmethod
    def load(self):
        ...

    @abstractmethod
    def generate(self, input: dict) -> Generator[dict, None, None]:
        ...


class Config:
    def __init__(self):
        self.HOST = os.environ["INFERD_HOST"]
        self.MODEL_ID = os.environ["INFERD_MODEL_ID"]
        self.WORKER_ID = str(uuid4())

    def channel(self) -> grpc.aio.Channel:
        return grpc.aio.insecure_channel(self.HOST)


M = TypeVar("M", bound=Model)
C = TypeVar("C", bound=Config)


async def run(model_cls: Type[Model], config_cls: Type[Config] = Config):
    event = Event()

    signal(SIGINT, lambda signum, frame: event.set())  # pyright: ignore unusedVariable

    await _run(event, model_cls, config_cls)

    logging.info("exiting")


async def _generate(stream: grpc.aio.UnaryStreamCall, stub: InferDStub, config: Config, model: Model):
    async for response in stream:
        if response == grpc.aio.EOF:
            break
        rids = [b.request_id for b in response.batch]
        logging.info(f"received batch size {len(response.batch)} with requests {', '.join(rids)}")

        try:
            batch_input = []
            for worker_input in response.batch:
                assert (
                    worker_input.model_id == config.MODEL_ID
                ), f"request model id does not match config model id: {config.MODEL_ID}"
                logging.debug(f"enqueing request {worker_input.request_id}")
                batch_input.append(json_format.MessageToDict(worker_input.input))

            async def generate_and_publish(i: dict):
                def iterator():
                    try:
                        output_generator = model.generate(i)
                        while True:
                            output = Struct()
                            start, duration = time_ns(), Duration()
                            out = next(output_generator, None)
                            if out is None:
                                break
                            output.update(out)
                            duration.FromNanoseconds(time_ns() - start)

                            worker_output = WorkerOutput(
                                output=output, inference_time=duration, queue_time=worker_input.queue_time
                            )
                            logging.debug("publishing output for request %s", worker_input.request_id)
                            yield PublishResultRequest(
                                worker_id=config.WORKER_ID, input=worker_input, output=worker_output
                            )
                    except Exception as e:
                        # TODO: dispatch error to stream
                        logging.error(e)
                        return

                await stub.PublishResult(iterator(), wait_for_ready=True)

            # TODO: implement dynamic batching instead of sequential processing
            for i in batch_input:
                await generate_and_publish(i)

        except Exception as e:
            # TODO: dispatch error to stream
            logging.error(e)
            continue


async def _run(event: Event, model_cls: Type[Model], config_cls: Type[Config] = Config):
    assert issubclass(model_cls, Model)
    assert issubclass(config_cls, Config)

    logging.info("initializing config")
    config = config_cls()
    channel = config.channel()
    stub = InferDStub(channel)

    logging.info("initializing model")
    model = model_cls()

    logging.info("loading model")
    model.load()

    logging.info("claiming work for model")
    claim_work_request = ClaimWorkRequest(model_id=config.MODEL_ID, worker_id=config.WORKER_ID)
    claim_work_stream = stub.ClaimWork(claim_work_request, wait_for_ready=True)

    async with TaskGroup() as tg:
        generate_task = tg.create_task(_generate(claim_work_stream, stub, config, model))
        await event.wait()
        generate_task.cancel()
        logging.info("shutting down")
