# This allows the relative imports in the auto-generated files in this directory to work.
# See https://github.com/protocolbuffers/protobuf/issues/1491 for more details.
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
