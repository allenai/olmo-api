import logging
import os
from abc import ABC, abstractmethod
from asyncio import CancelledError, Event, Queue, create_task, gather
from dataclasses import asdict, dataclass
from signal import SIGINT, signal
from time import time_ns
from typing import Callable, Generator, Optional, TypeVar

import grpc
from google.protobuf import json_format
from google.protobuf.duration_pb2 import Duration
from google.protobuf.struct_pb2 import Struct
from google.protobuf.timestamp_pb2 import Timestamp

from .msg.inferd_pb2 import (
    ClaimWorkRequest,
    ClaimWorkResponse,
    PublishResultRequest,
    RegisterComputeWorkerRequest,
    RegisterComputeWorkerResponse,
    WorkerOutput,
)
from .msg.inferd_pb2_grpc import InferDStub


class Model(ABC):
    def __init__(self):
        ...

    @abstractmethod
    def load(self):
        ...

    def generate(self, inp: dict) -> Generator[dict, None, None]:
        """
        Invoked by the InferD client to generate an output dictionary from an input dictionary. Should
        be implemented only if the model does not support batching.
        """
        # If this method is called, it means that the subclass has not implemented generate OR batch_generate.
        raise NotImplementedError("subclass of Model must implement batch_generate or generate")

    def batch_generate(self, inputs: list[dict]) -> Generator[list[Optional[dict]], None, None]:
        """
        Invoked by the InferD client to generate a batch of output dictionaries from a batch of input
        dictionaries. the implementation should yield a list of dictionaries always exactly the same length as
        the input list. If some inputs end before others, the corresponding output must be None.

        We provide a naive sequential batch implementation. Models should override this method with
        GPU batching, but do not have to if they do not care about efficiency.
        """

        generators = [self.generate(inp) for inp in inputs]
        while True:
            outputs: list[Optional[dict]] = []
            for gen in generators:
                try:
                    outputs.append(next(gen))
                except StopIteration:
                    outputs.append(None)
            if all(o is None for o in outputs):
                return
            yield outputs


@dataclass
class Config:
    host: str
    compute_source_id: str
    batch_size: int = 1
    max_claimed_batches: int = 1
    block_timeout_ms: int = 100
    token: Optional[str] = None
    use_insecure_channel: bool = False

    @classmethod
    def from_env(cls) -> "Config":
        return Config(
            host=os.environ["INFERD_HOST"],
            compute_source_id=os.environ["INFERD_COMPUTE_SOURCE_ID"],
            batch_size=int(os.environ.get("INFERD_BATCH_SIZE", 1)),
            max_claimed_batches=int(os.environ.get("INFERD_MAX_CLAIMED_BATCHES", 1)),
            block_timeout_ms=int(os.environ.get("INFERD_BLOCK_TIMEOUT_MS", 100)),
            token=os.environ.get("INFERD_TOKEN"),
            use_insecure_channel=os.environ.get("INFERD_USE_INSECURE_GRPC_CHANNEL", "false").lower() == "true",
        )

    def channel(self) -> grpc.aio.Channel:
        if self.use_insecure_channel:
            return grpc.aio.insecure_channel(self.host)
        else:
            return grpc.aio.secure_channel(self.host, grpc.ssl_channel_credentials())

    def build_metadata(self) -> tuple[tuple[str, Optional[str]]]:
        return (("x-inferd-token", self.token),)


M = TypeVar("M", bound=Model)
C = TypeVar("C", bound=Config)


async def run(model: Model, config: Optional[Config] = None):
    # Initialize the config from the environment if it is not provided.
    if config is None:
        config = Config.from_env()

    event = Event()
    signal(SIGINT, lambda signum, frame: event.set())  # pyright: ignore unusedVariable
    await _run(event, model, config)
    logging.info("exiting...")


async def _generate(stream: grpc.aio.UnaryStreamCall, stub: InferDStub, config: Config, model: Model, worker_id: str):
    try:
        logging.info("waiting for work...")
        response: ClaimWorkResponse
        async for response in stream:
            if response == grpc.aio.EOF:
                logging.info("received EOF from stream; exiting generate...")
                break
            ids = [b.metadata.inference_id for b in response.batch]
            logging.info(f"received batch size {len(response.batch)} with inferences {', '.join(ids)}")

            try:
                worker_inputs = []
                for inp in response.batch:
                    if inp.metadata.compute_source_id != config.compute_source_id:
                        logging.error(
                            f"request compute source id does not match config compute source id: {config.compute_source_id}"
                        )
                        continue
                    if inp.metadata.compute_worker_id != worker_id:
                        logging.error(f"request compute worker id does not match config compute worker id: {worker_id}")
                        continue
                    logging.debug(f"enqueuing inference {inp.metadata.inference_id}")
                    worker_inputs.append(inp)

                if len(worker_inputs) == 0:
                    continue

                # Create the batch generator and pass in the worker inputs as a list of dicts.
                output_generator = model.batch_generate([json_format.MessageToDict(inp.input) for inp in worker_inputs])

                # Initialize a list of queues, one for each worker input.
                # Each queue has a maxsize of 1, so that we can block on putting
                # more than 1 output into the queue, ensuring that we yield to the
                # consumer function (the publishing GRPC stream iterator) so
                # requests are streamed as they are generated instead of waiting
                # for the entire batch to be generated.
                queues: list[Queue[Optional[dict]]] = [Queue(maxsize=1) for _ in range(len(worker_inputs))]

                async def enqueue_generated_outputs():
                    # We track the completeness of each queue so that we don't repeatedly put None
                    # into a queue that no longer has a consumer.
                    complete = [False for _ in range(len(queues))]
                    while True:
                        # Get the next batch of outputs from the model.
                        try:
                            outputs: list[Optional[dict]] = next(output_generator)
                        except StopIteration:
                            for i in range(len(queues)):
                                if not complete[i]:
                                    await queues[i].put(None)
                            return

                        assert len(outputs) == len(worker_inputs), (
                            "generation must return a batch of outputs with the same size as the batch of inputs, "
                            "using None to signal completion of individual requests smaller than the batch"
                        )
                        # Put the outputs into the queues if the queue is not complete
                        # (we have already put None into it and the consumer is gone),
                        # and mark the queue as complete if the output is None.
                        for i, out in enumerate(outputs):
                            if complete[i]:
                                continue
                            await queues[i].put(out)
                            if out is None:
                                complete[i] = True

                async def publish(i):
                    async def iterator():
                        try:
                            started_inference_at = Timestamp()
                            started_inference_at.FromNanoseconds(time_ns())
                            part = 0
                            while True:
                                output_struct = Struct()
                                out = await queues[i].get()
                                if out is None:
                                    logging.debug(
                                        f"finished publishing {part} parts for inference {worker_inputs[i].metadata.inference_id}"
                                    )
                                    return
                                output_struct.update(out)
                                completed_inference_at = Timestamp()
                                completed_inference_at.FromNanoseconds(time_ns())

                                worker_output = WorkerOutput(
                                    metadata=worker_inputs[i].metadata,
                                    started_inference_at=started_inference_at,
                                    completed_inference_at=completed_inference_at,
                                    output=output_struct,
                                )
                                yield PublishResultRequest(
                                    output=worker_output,
                                )
                                logging.debug(
                                    f"published part {part} for inference {worker_inputs[i].metadata.inference_id}"
                                )
                                part += 1
                        except Exception as e:
                            logging.exception(e)

                    await stub.PublishResult(iterator(), wait_for_ready=True, metadata=config.build_metadata())

                # Run the enqueueing and publishing coroutines concurrently and wait for them to finish.
                await gather(*[enqueue_generated_outputs(), *[publish(i) for i in range(len(worker_inputs))]])

            except Exception as e:
                # TODO: dispatch error to stream
                logging.exception(e)
                continue

            logging.debug(f"finished processing batch with inferences {', '.join(ids)}")

    except CancelledError:
        logging.info("caught CancelledError exception; exiting generate...")
        raise

    logging.info("exiting generate...")


async def _monitor_channel_state(channel: grpc.aio.Channel, callback: Callable):
    while True:
        state = channel.get_state()
        callback(state)
        await channel.wait_for_state_change(state)


async def _run(event: Event, model: Model, config: Config):
    logging.info(f"registering worker with config {config}...")
    channel = config.channel()

    # Start a task to monitor the channel state in the background and log state changes.
    _ = create_task(_monitor_channel_state(channel, lambda state: logging.info(f"channel state: {state}")))
    stub = InferDStub(channel)

    worker_details = Struct()
    # Exclude the token from the worker details.
    worker_details.update({k: v for k, v in asdict(config).items() if k != "token"})
    register_compute_worker_request = RegisterComputeWorkerRequest(
        compute_source_id=config.compute_source_id,
        worker_details=worker_details,
    )
    register_compute_worker_response: RegisterComputeWorkerResponse = await stub.RegisterComputeWorker(
        register_compute_worker_request, wait_for_ready=True, metadata=config.build_metadata()
    )
    worker_id = register_compute_worker_response.compute_worker.id

    logging.info(f"loading model with config {config}...")
    model.load()

    # Wrap the ClaimWork stream connection in a retry loop, since this is a long-running connection. If the
    # connection is lost, we want to retry, which will block until the server becomes available again. Therefore,
    # we don't need to use an exponential backoff strategy here.
    while True:
        generate_task = None
        try:
            logging.info(
                f"claiming work in batches of size {config.batch_size} for compute source {config.compute_source_id}..."
            )
            block_timeout = Duration()
            block_timeout.FromMilliseconds(config.block_timeout_ms)
            claim_work_request = ClaimWorkRequest(
                compute_source_id=config.compute_source_id,
                compute_worker_id=worker_id,
                batch_size=config.batch_size,
                block_timeout=block_timeout,
                max_claimed_batches=config.max_claimed_batches,
            )
            claim_work_stream = stub.ClaimWork(
                claim_work_request, wait_for_ready=True, metadata=config.build_metadata()
            )
            # Start the generate task to receive work from the stream and process it in the background.
            generate_task = create_task(_generate(claim_work_stream, stub, config, model, worker_id))
            # When the generate task is done, we set the event to signal that the stream was closed.
            generate_task.add_done_callback(lambda _: event.set())

            # If the event is set, we either received a signal to exit or the stream was closed.
            await event.wait()
            # If the generate task is done, we know we sent the event was set using the done callback, which
            # means the stream was closed, and we should reset the event and continue the loop to re-establish
            # the connection.
            if generate_task.done():
                logging.info("stream disconnected; retrying...")
                event.clear()
                continue
            # If the generate task wasn't done, we received a signal to exit, so we cancel that task
            # and break the loop.
            generate_task.cancel()
            break

        # If the exception is a retryable error, we continue the loop and retry the connection.
        except grpc.aio.AioRpcError as err:
            # If the error is retryable (probably b/c the socket got lost) continue, otherwise re-raise.
            if isinstance(err, grpc.aio.AioRpcError) and err.code() == grpc.StatusCode.UNAVAILABLE:
                logging.warning("caught grpc.aio.AioRpcError exception with status=UNAVAILABLE; retrying...")
                continue
            raise err

        finally:
            if generate_task is not None:
                generate_task.cancel()

    logging.info("exiting worker...")
