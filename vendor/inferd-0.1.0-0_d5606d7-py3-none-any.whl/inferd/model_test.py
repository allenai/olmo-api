import unittest
from asyncio import Event
from typing import Generator
from unittest.mock import MagicMock

import grpc
from google.protobuf.duration_pb2 import Duration
from google.protobuf.struct_pb2 import Struct, Value

from .model import Config, Model, _run
from .msg.inferd_pb2 import ClaimWorkRequest, ClaimWorkResponse, WorkerInput


class TestRun(unittest.IsolatedAsyncioTestCase):
    async def test_run(self):
        test_channel = MagicMock(name="channel")

        test = self
        load_called = False

        class _TestModel(Model):
            def load(self):
                nonlocal load_called
                load_called = True

            def generate(self, input: dict) -> Generator[dict, None, None]:
                test.assertEqual(input, {"input": "test-in"})
                yield {"output": "test-out"}

        class _TestConfig(Config):
            def __init__(self):
                self.MODEL_ID = "test-model-id"
                self.WORKER_ID = "test-worker-id"

            def channel(self) -> grpc.aio.Channel:
                return test_channel

        mock_claim_work_stream = MagicMock(name="mock_claim_work_stream")
        mock_claim_work_stream.__aiter__.return_value = iter(
            [
                ClaimWorkResponse(
                    batch=[
                        WorkerInput(
                            request_id="test-request-id",
                            queue_id="test-queue-id",
                            model_id="test-model-id",
                            queue_time=Duration(seconds=1),
                            input=Struct(fields={"input": Value(string_value="test-in")}),
                        )
                    ]
                ),
            ]
        )
        mock_claim_work_stream.__anext__.side_effect = mock_claim_work_stream.__aiter__.return_value.__next__

        mock_publish_results_stream = MagicMock(name="mock_publish_results_stream")

        event = Event()

        def claim_work_handler(claim_work_request, wait_for_ready):
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(claim_work_request, ClaimWorkRequest(model_id="test-model-id", worker_id="test-worker-id"))
            return mock_claim_work_stream

        def publish_result_handler(publish_result_request_stream, wait_for_ready):
            publish_result_request = next(publish_result_request_stream)
            self.assertEqual(wait_for_ready, True)
            self.assertEqual(publish_result_request.worker_id, "test-worker-id")
            self.assertEqual(
                publish_result_request.input,
                WorkerInput(
                    request_id="test-request-id",
                    queue_id="test-queue-id",
                    model_id="test-model-id",
                    queue_time=Duration(seconds=1),
                    input=Struct(fields={"input": Value(string_value="test-in")}),
                ),
            )
            self.assertEqual(
                publish_result_request.output.output, Struct(fields={"output": Value(string_value="test-out")})
            )
            self.assertEqual(publish_result_request.output.queue_time, Duration(seconds=1))
            self.assertGreater(publish_result_request.output.inference_time.ToNanoseconds(), 0)
            event.set()
            return mock_publish_results_stream

        # ClaimWork is currently the only unary_stream method and PublishResult is the only stream_unary method,
        # so we can mock them directly here.
        test_channel.unary_stream.return_value = MagicMock(name="claim_work_handler", side_effect=claim_work_handler)
        test_channel.stream_unary.return_value = MagicMock(
            name="publish_result_handler", side_effect=publish_result_handler
        )

        await _run(event, _TestModel, _TestConfig)
        self.assertTrue(load_called)
