class InferDError(Exception):
    """Base class for all InferD errors."""


class ConfigError(InferDError):
    """Raised when the InferD server configuration is invalid."""


class InvalidReferenceError(InferDError):
    """Raised when the model reference is invalid."""
